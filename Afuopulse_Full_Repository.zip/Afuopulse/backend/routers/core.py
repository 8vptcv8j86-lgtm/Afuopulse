import os, uuid, hmac, hashlib, base64, csv, io
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, Literal
import stripe
from fastapi import APIRouter, Depends, Form, Header, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, EmailStr, HttpUrl
from xml.sax.saxutils import escape
from agents import REGISTRY, get_agent_class
from db import db, EMERGENT_LLM_KEY, STRIPE_API_KEY, APP_ENV
from deps import get_current_user, hash_pw, make_token, now_iso, require_gov, verify_pw

router=APIRouter()
class RegisterIn(BaseModel):
    email:EmailStr; password:str; name:str; role:Literal["farmer","officer","government"]="farmer"; country:str="KE"; language:str="en"
class LoginIn(BaseModel): email:EmailStr; password:str
class FarmIn(BaseModel): name:str; country:str; region:str|None=None; crops:list[str]=[]; acreage:float|None=None
class AgentRunIn(BaseModel): payload:Dict[str,Any]; context:Dict[str,Any]|None=None
class CheckoutIn(BaseModel): tier:Literal["regional","national"]; origin_url:HttpUrl
class BroadcastIn(BaseModel): country:str; title:str; message:str; severity:str="warning"; priority:bool=False

@router.post("/auth/register")
async def register(b:RegisterIn):
    if await db.users.find_one({"email":b.email.lower()}): raise HTTPException(400,"Email already registered")
    d={"id":str(uuid.uuid4()),"email":b.email.lower(),"password":hash_pw(b.password),"name":b.name,"role":b.role,"country":b.country,"language":b.language,"created_at":now_iso(),"subscription_active_until":None,"subscription_tier":None}
    await db.users.insert_one(d.copy()); return {"token":make_token(d["id"]),"user":{k:v for k,v in d.items() if k!="password"}}
@router.post("/auth/login")
async def login(b:LoginIn):
    u=await db.users.find_one({"email":b.email.lower()})
    if not u or not verify_pw(b.password,u["password"]): raise HTTPException(401,"Invalid email or password")
    return {"token":make_token(u["id"]),"user":{k:v for k,v in u.items() if k not in {"_id","password"}}}
@router.get("/auth/me")
async def me(u=Depends(get_current_user)): return u
@router.post("/farms")
async def create_farm(b:FarmIn,u=Depends(get_current_user)):
    d={"id":str(uuid.uuid4()),"owner_id":u["id"],**b.model_dump(),"created_at":now_iso()}; await db.farms.insert_one(d.copy()); return d
@router.get("/farms")
async def farms(u=Depends(get_current_user)): return await db.farms.find({"owner_id":u["id"]},{"_id":0}).to_list(100)
@router.get("/agents")
async def agents(u=Depends(get_current_user)):
    return {"agents":[c.metadata() for c in REGISTRY.values() if not c.role_required or c.role_required==u.get("role")]}
@router.post("/agents/{name}/run")
async def run_agent(name:str,b:AgentRunIn,u=Depends(get_current_user)):
    try: cls=get_agent_class(name)
    except KeyError: raise HTTPException(404,"Unknown agent")
    if cls.role_required and cls.role_required!=u.get("role"): raise HTTPException(403,"Role not permitted")
    r=await cls(EMERGENT_LLM_KEY).run(b.payload,ctx=b.context or {}); return r.to_dict()

def active(u):
    try: return bool(u.get("subscription_active_until") and datetime.fromisoformat(u["subscription_active_until"])>datetime.now(timezone.utc))
    except Exception: return False
@router.get("/gov/stats")
async def gov_stats(u=Depends(require_gov)):
    return {"kpis":{"farmers":await db.users.count_documents({"role":"farmer"}),"provisional_cases":await db.diagnoses.count_documents({})},"subscription":{"active":active(u),"tier":u.get("subscription_tier"),"until":u.get("subscription_active_until")}}
@router.post("/gov/broadcast")
async def broadcast(b:BroadcastIn,u=Depends(require_gov)):
    if b.priority and not active(u): raise HTTPException(402,"Paid access required")
    d={"id":str(uuid.uuid4()),**b.model_dump(),"status":"draft_pending_review","created_at":now_iso(),"created_by":u["id"]}; await db.alerts.insert_one(d.copy()); return d
@router.get("/gov/export/provisional-cases")
async def export_cases(u=Depends(require_gov)):
    if not active(u): raise HTTPException(402,"Paid access required")
    out=io.StringIO(); w=csv.writer(out); w.writerow(["id","date","country","status","confidence"])
    for d in await db.diagnoses.find({}, {"_id":0}).limit(5000).to_list(5000): w.writerow([d.get("id"),d.get("created_at"),d.get("region"),d.get("status"),d.get("confidence")])
    return Response(out.getvalue(),media_type="text/csv",headers={"Content-Disposition":'attachment; filename="afuopulse_provisional_cases.csv"'})
PLANS={"regional":{"amount":19900,"days":30},"national":{"amount":49900,"days":30}}
@router.get("/billing/plans")
async def plans(): return {"plans":[{"tier":k,"amount_usd":v["amount"]/100,"days":v["days"]} for k,v in PLANS.items()]}
@router.post("/billing/checkout")
async def checkout(b:CheckoutIn,u=Depends(require_gov)):
    if not STRIPE_API_KEY: raise HTTPException(500,"Stripe not configured")
    stripe.api_key=STRIPE_API_KEY; p=PLANS[b.tier]; origin=str(b.origin_url).rstrip("/")
    s=stripe.checkout.Session.create(mode="payment",payment_method_types=["card"],line_items=[{"price_data":{"currency":"usd","product_data":{"name":f"Afuopulse {b.tier} 30-day access"},"unit_amount":p["amount"]},"quantity":1}],success_url=f"{origin}/billing/return?session_id={{CHECKOUT_SESSION_ID}}",cancel_url=f"{origin}/billing/cancel",metadata={"user_id":u["id"],"tier":b.tier,"days":str(p["days"])})
    return {"url":s.url,"session_id":s.id}
@router.post("/channels/whatsapp/twilio")
async def whatsapp(request:Request,Body:str=Form(""),From:str=Form(""),WaId:str=Form(""),x_twilio_signature:str|None=Header(None)):
    token=os.environ.get("TWILIO_AUTH_TOKEN","")
    if token:
        raw=str(request.url)+"Body"+Body+"From"+From+"WaId"+WaId; expected=base64.b64encode(hmac.new(token.encode(),raw.encode(),hashlib.sha1).digest()).decode()
        if not x_twilio_signature or not hmac.compare_digest(expected,x_twilio_signature): raise HTTPException(401,"Invalid Twilio signature")
    elif APP_ENV=="production": raise HTTPException(503,"Twilio verification not configured")
    reply="Afuopulse: ask about crops, field observations, or type help."; return Response(f'<?xml version="1.0"?><Response><Message>{escape(reply)}</Message></Response>',media_type="application/xml")
@router.post("/channels/ussd/at")
async def ussd(text:str=Form(""),x_afuopulse_secret:str|None=Header(None)):
    secret=os.environ.get("AT_WEBHOOK_SECRET","")
    if secret and (not x_afuopulse_secret or not hmac.compare_digest(secret,x_afuopulse_secret)): raise HTTPException(401,"Invalid callback signature")
    if not secret and APP_ENV=="production": raise HTTPException(503,"USSD verification not configured")
    return Response("CON Afuopulse\n1. Record field observation\n2. View alerts\n3. Ask agronomist\n4. Report urgent crop risk" if not text else "END Workflow received.",media_type="text/plain")
